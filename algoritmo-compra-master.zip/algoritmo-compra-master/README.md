# algoritmo-compra
projeto visa criar um algoritmo para solucionar o problema das superlotação nos estabelecimento de supermercado,onde esse programa pudesse permitir que as pessoas fizessem comprar via web,e esse sistema como uma especie de carrinho de compra
